import React, { useState } from 'react';
import { AuthView } from './types';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import Dashboard from './components/Dashboard';

function App() {
  const [currentView, setCurrentView] = useState<AuthView>('login');

  const handleViewChange = (view: AuthView) => {
    setCurrentView(view);
  };

  return (
    <div className="App">
      {currentView === 'login' && <LoginPage onViewChange={handleViewChange} />}
      {currentView === 'signup' && <SignupPage onViewChange={handleViewChange} />}
      {currentView === 'dashboard' && <Dashboard onViewChange={handleViewChange} />}
    </div>
  );
}

export default App;