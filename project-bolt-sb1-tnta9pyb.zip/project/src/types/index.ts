export interface Alert {
  id: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  timestamp: Date;
  type: string;
  resolved: boolean;
}

export interface User {
  id: string;
  email: string;
  businessName: string;
  name: string;
}

export type AuthView = 'login' | 'signup' | 'dashboard';