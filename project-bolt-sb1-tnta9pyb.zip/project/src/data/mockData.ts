import { Alert } from '../types';

export const mockAlerts: Alert[] = [
  {
    id: '1',
    title: 'Suspicious Login Attempt Detected',
    description: 'Multiple failed login attempts detected from an unusual location (Russia). Account automatically secured.',
    severity: 'critical',
    timestamp: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
    type: 'Authentication',
    resolved: false,
  },
  {
    id: '2',
    title: 'Malware Blocked on Employee Device',
    description: 'Potentially harmful file blocked from downloading on Sarah\'s laptop. No action required.',
    severity: 'high',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    type: 'Endpoint Protection',
    resolved: true,
  },
  {
    id: '3',
    title: 'Unusual Network Traffic Pattern',
    description: 'Increased data transfer detected during off-hours. Monitoring continues.',
    severity: 'medium',
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
    type: 'Network Security',
    resolved: false,
  },
  {
    id: '4',
    title: 'Security Update Available',
    description: 'Important security patch available for your email server. Schedule installation recommended.',
    severity: 'medium',
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
    type: 'System Updates',
    resolved: false,
  },
  {
    id: '5',
    title: 'Phishing Email Quarantined',
    description: 'Suspicious email claiming to be from your bank was automatically quarantined before reaching inboxes.',
    severity: 'high',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    type: 'Email Security',
    resolved: true,
  },
];

export const mockThreatHistory: Alert[] = [
  ...mockAlerts,
  {
    id: '6',
    title: 'Password Policy Violation',
    description: 'Weak password detected for user account. Password reset notification sent.',
    severity: 'low',
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    type: 'Access Control',
    resolved: true,
  },
  {
    id: '7',
    title: 'Firewall Configuration Updated',
    description: 'Firewall rules automatically updated to block known malicious IP addresses.',
    severity: 'low',
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    type: 'Network Security',
    resolved: true,
  },
  {
    id: '8',
    title: 'Data Backup Completed Successfully',
    description: 'Weekly automated backup completed without issues. All critical data secured.',
    severity: 'low',
    timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
    type: 'Data Protection',
    resolved: true,
  },
];