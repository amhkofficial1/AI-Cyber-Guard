import React, { useState } from 'react';
import { Clock, Filter, Search } from 'lucide-react';
import { Alert } from '../types';
import AlertCard from './AlertCard';

interface ThreatHistoryProps {
  threats: Alert[];
}

export default function ThreatHistory({ threats }: ThreatHistoryProps) {
  const [filter, setFilter] = useState<'all' | 'critical' | 'high' | 'medium' | 'low'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredThreats = threats
    .filter(threat => filter === 'all' || threat.severity === filter)
    .filter(threat => 
      threat.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      threat.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Clock className="h-6 w-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">Threat History</h2>
        </div>
        <div className="text-sm text-slate-400">
          {filteredThreats.length} events
        </div>
      </div>

      {/* Search and Filter Controls */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-400" />
          </div>
          <input
            type="text"
            placeholder="Search threats..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors text-sm"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-slate-400" />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as any)}
            className="bg-slate-700 border border-slate-600 rounded-lg text-white text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {/* Threats List */}
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {filteredThreats.length > 0 ? (
          filteredThreats.map((threat) => (
            <AlertCard key={threat.id} alert={threat} />
          ))
        ) : (
          <div className="text-center py-8">
            <div className="text-slate-400 mb-2">No threats match your search criteria</div>
            <button
              onClick={() => {
                setFilter('all');
                setSearchTerm('');
              }}
              className="text-blue-400 hover:text-blue-300 transition-colors text-sm"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}