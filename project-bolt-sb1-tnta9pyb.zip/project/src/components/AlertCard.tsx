import React from 'react';
import { AlertTriangle, Shield, CheckCircle, Clock } from 'lucide-react';
import { Alert } from '../types';

interface AlertCardProps {
  alert: Alert;
}

const severityConfig = {
  critical: {
    color: 'border-red-500 bg-red-500/10',
    textColor: 'text-red-400',
    icon: AlertTriangle,
    badge: 'bg-red-500 text-white',
  },
  high: {
    color: 'border-orange-500 bg-orange-500/10',
    textColor: 'text-orange-400',
    icon: AlertTriangle,
    badge: 'bg-orange-500 text-white',
  },
  medium: {
    color: 'border-yellow-500 bg-yellow-500/10',
    textColor: 'text-yellow-400',
    icon: Shield,
    badge: 'bg-yellow-500 text-black',
  },
  low: {
    color: 'border-blue-500 bg-blue-500/10',
    textColor: 'text-blue-400',
    icon: Shield,
    badge: 'bg-blue-500 text-white',
  },
};

export default function AlertCard({ alert }: AlertCardProps) {
  const config = severityConfig[alert.severity];
  const SeverityIcon = config.icon;
  
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 60) {
      return `${diffMins} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else {
      return `${diffDays} days ago`;
    }
  };

  return (
    <div className={`border-l-4 rounded-lg p-4 bg-slate-800 ${config.color} hover:bg-slate-750 transition-colors`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 flex-1">
          <div className={`p-2 rounded-full ${config.color}`}>
            <SeverityIcon className={`h-5 w-5 ${config.textColor}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-white font-semibold text-sm">
                {alert.title}
              </h3>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.badge}`}>
                {alert.severity.toUpperCase()}
              </span>
              {alert.resolved && (
                <CheckCircle className="h-4 w-4 text-green-400" />
              )}
            </div>
            <p className="text-slate-300 text-sm leading-relaxed mb-3">
              {alert.description}
            </p>
            <div className="flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {formatTimeAgo(alert.timestamp)}
                </span>
                <span className="px-2 py-1 bg-slate-700 rounded text-slate-300">
                  {alert.type}
                </span>
              </div>
              {alert.resolved && (
                <span className="text-green-400 font-medium">
                  Resolved
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}