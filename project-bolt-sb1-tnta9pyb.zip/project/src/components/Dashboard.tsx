import React, { useState, useEffect } from 'react';
import { AlertTriangle, Shield, Activity, TrendingUp, RefreshCw } from 'lucide-react';
import { Alert, AuthView } from '../types';
import { mockAlerts, mockThreatHistory } from '../data/mockData';
import AlertCard from './AlertCard';
import ThreatHistory from './ThreatHistory';
import Navigation from './Navigation';

interface DashboardProps {
  onViewChange: (view: AuthView) => void;
}

export default function Dashboard({ onViewChange }: DashboardProps) {
  const [alerts, setAlerts] = useState<Alert[]>(mockAlerts);
  const [activeSection, setActiveSection] = useState<'dashboard' | 'history'>('dashboard');
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const handleLogout = () => {
    onViewChange('login');
  };

  const handleSectionChange = (section: AuthView) => {
    if (section === 'dashboard') {
      setActiveSection('dashboard');
    } else if (section === 'history') {
      setActiveSection('history');
    }
    // Settings would be handled here in a full implementation
  };

  const refreshData = () => {
    setLastUpdated(new Date());
    // In a real app, this would fetch fresh data
  };

  const criticalAlerts = alerts.filter(alert => alert.severity === 'critical' && !alert.resolved).length;
  const highAlerts = alerts.filter(alert => alert.severity === 'high' && !alert.resolved).length;
  const resolvedToday = alerts.filter(alert => {
    const today = new Date();
    const alertDate = alert.timestamp;
    return alert.resolved && 
           alertDate.getDate() === today.getDate() && 
           alertDate.getMonth() === today.getMonth() && 
           alertDate.getFullYear() === today.getFullYear();
  }).length;

  const currentAlerts = alerts.filter(alert => !alert.resolved).slice(0, 5);

  return (
    <div className="min-h-screen bg-slate-900">
      <Navigation 
        activeView={activeSection} 
        onViewChange={handleSectionChange} 
        onLogout={handleLogout} 
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeSection === 'dashboard' && (
          <>
            {/* Header */}
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2">Security Dashboard</h1>
                <p className="text-slate-400">
                  Last updated: {lastUpdated.toLocaleTimeString()}
                </p>
              </div>
              <button
                onClick={refreshData}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <RefreshCw className="h-4 w-4" />
                Refresh
              </button>
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">Critical Alerts</p>
                    <p className="text-2xl font-bold text-red-400">{criticalAlerts}</p>
                  </div>
                  <div className="p-3 bg-red-500/10 rounded-lg">
                    <AlertTriangle className="h-6 w-6 text-red-400" />
                  </div>
                </div>
              </div>

              <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">High Priority</p>
                    <p className="text-2xl font-bold text-orange-400">{highAlerts}</p>
                  </div>
                  <div className="p-3 bg-orange-500/10 rounded-lg">
                    <Shield className="h-6 w-6 text-orange-400" />
                  </div>
                </div>
              </div>

              <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">System Status</p>
                    <p className="text-2xl font-bold text-green-400">Secure</p>
                  </div>
                  <div className="p-3 bg-green-500/10 rounded-lg">
                    <Activity className="h-6 w-6 text-green-400" />
                  </div>
                </div>
              </div>

              <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-400 text-sm font-medium">Resolved Today</p>
                    <p className="text-2xl font-bold text-blue-400">{resolvedToday}</p>
                  </div>
                  <div className="p-3 bg-blue-500/10 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-blue-400" />
                  </div>
                </div>
              </div>
            </div>

            {/* Real-time Alerts Section */}
            <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 mb-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                  <h2 className="text-xl font-bold text-white">Real-time Security Alerts</h2>
                </div>
                <div className="text-sm text-slate-400">
                  {currentAlerts.length} active alerts
                </div>
              </div>

              <div className="space-y-4">
                {currentAlerts.length > 0 ? (
                  currentAlerts.map((alert) => (
                    <AlertCard key={alert.id} alert={alert} />
                  ))
                ) : (
                  <div className="text-center py-8">
                    <Shield className="h-12 w-12 text-green-400 mx-auto mb-4" />
                    <div className="text-white font-medium mb-2">All systems secure</div>
                    <div className="text-slate-400 text-sm">No active security alerts at this time</div>
                  </div>
                )}
              </div>

              {currentAlerts.length > 0 && (
                <div className="mt-6 text-center">
                  <button
                    onClick={() => setActiveSection('history')}
                    className="text-blue-400 hover:text-blue-300 transition-colors font-medium"
                  >
                    View all alerts in history →
                  </button>
                </div>
              )}
            </div>
          </>
        )}

        {activeSection === 'history' && (
          <ThreatHistory threats={mockThreatHistory} />
        )}
      </div>
    </div>
  );
}